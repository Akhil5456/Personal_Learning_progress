package com.studenttracker.model;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@Entity
@Table(name = "students")
public class Student {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true)
    private String username;

    @Column(nullable = false)
    private String password; // BCrypt hash

    // Security question answers (hashed for safety)
    @Column(nullable = false)
    private String securityAnswer1;

    @Column(nullable = false)
    private String securityAnswer2;

    @Column(nullable = false)
    private String securityAnswer3;
}
