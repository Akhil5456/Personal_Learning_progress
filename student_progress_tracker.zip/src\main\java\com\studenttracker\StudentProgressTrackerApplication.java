package com.studenttracker;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentProgressTrackerApplication {
    public static void main(String[] args) {
        SpringApplication.run(StudentProgressTrackerApplication.class, args);
    }
}
